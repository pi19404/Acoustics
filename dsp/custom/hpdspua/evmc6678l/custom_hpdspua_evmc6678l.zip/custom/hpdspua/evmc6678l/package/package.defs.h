/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-v56
 */

#ifndef custom_hpdspua_evmc6678l__
#define custom_hpdspua_evmc6678l__



#endif /* custom_hpdspua_evmc6678l__ */ 
